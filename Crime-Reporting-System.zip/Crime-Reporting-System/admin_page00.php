<!DOCTYPE html>
<html>
<head>
	<title>Complainer Home Page</title>

	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">

	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">

	<link href="http://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">

	<link href="complainer_page.css" rel="stylesheet" type="text/css" media="all" />
	<?php
    session_start();
    if(!isset($_SESSION['x']))
        header("location:inchargelogin.php");
    
    $con=mysqli_connect('localhost','root','','crime_portal');
    if(!$con)
    {
        die('could not connect: '.mysqli_error());
    }
    mysqli_select_db($con, 'crime_portal');

    
    // $i_id=$_SESSION['email'];

    // $result1=mysqli_query($con,"SELECT location FROM police_station where i_id='$i_id'");
      
    // $q2=mysqli_fetch_assoc($result1);
    // $location=$q2['location'];
    
    if(isset($_POST['s'])){
        if($_SERVER["REQUEST_METHOD"]=="POST"){
            $u_name=$_POST['user_name'];
            $u_id=$_POST['user_id'];
            $u_pass=$_POST['password'];
            $u_addr=$_POST['address'];
            $a_no=$_POST['adhar'];
            $gen=$_POST['gender'];
            $mob=$_POST['mobile'];
    
            // Check if user_id already exists
            $check_query = "SELECT * FROM user WHERE u_id='$u_id'";
            $check_result = mysqli_query($con, $check_query);
            if(mysqli_num_rows($check_result) > 0) {
                $message = "User with this ID already exists.";
                echo "<script type='text/javascript'>alert('$message');</script>";
            } else {
                // Insert user data into the database
                $reg="INSERT INTO user VALUES('$u_name','$u_id','$u_pass','$u_addr','$a_no','$gen','$mob')";
                $res=mysqli_query($con,$reg);
                if(!$res) {
                    $message = "Failed to add user.";
                    echo "<script type='text/javascript'>alert('$message');</script>";
                } else {
                    $message = "User Added Successfully";
                    echo "<script type='text/javascript'>alert('$message');</script>";
                }
            }
        }
    }
    
?>
    
     <script>
     function f1()
    {
      var sta=document.getElementById("uname").value;
      var sta1=document.getElementById("uid").value;
      var sta2=document.getElementById("password").value;
      var sta3=document.getElementById("address").value;
      var sta4=document.getElementById("adhar").value;
      var sta5=document.getElementById("gender").value;
      var sta6=document.getElementById("mobile").value;
      var x=sta.trim();
      var x1=sta1.indexOf(' ');
      var x2=sta2.trim();
      var x3=sta3.indexOf(' ');
  if(sta!="" && x==""){
    document.getElementById("uname").value="";
    document.getElementById("uname").focus();
      alert("Space Not Allowed");
        }
        
         else if(sta1!="" && x1>=0){
    document.getElementById("uid").value="";
    document.getElementById("uid").focus();
      alert("Space Not Allowed");
        }
        else if(sta2!="" && x2==""){
    document.getElementById("password").value="";
    document.getElementById("password").focus();
      alert("Space Not Allowed");
        }
        else if(sta3!="" && x3>=0){
    document.getElementById("address").value="";
    document.getElementById("address").focus();
      alert("Space Not Allowed");
        }   
        else if(sta4!="" && x1>=0){
    document.getElementById("adhar").value="";
    document.getElementById("adhar").focus();
      alert("Space Not Allowed");
        }
        else if(sta5!="" && x2==""){
    document.getElementById("gender").value="";
    document.getElementById("gender").focus();
      alert("Space Not Allowed");
        }
        else if(sta6!="" && x3>=0){
    document.getElementById("mobile").value="";
    document.getElementById("mobile").focus();
      alert("Space Not Allowed");   
}}
</script>
</head>

<body style="background-size: cover;
    background-image: url(home_bg1.jpeg);
    background-position: center;">
	<nav  class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="home.php"><b>Crime Portal_Admin</b></a>
    </div>
    <div id="navbar" class="collapse navbar-collapse">
      
      <ul class="nav navbar-nav">
        <li><a href="admin_page.php">User</a></li>
        <li><a href="admin1_page.php">Police</a></li>
        <li><a href="admin2_page.php">Police Station</a></li>
        <li><a href="admin3_page.php">Head Quarter</a></li>
        <li><a href="admin4_page.php">Complaints</a></li>

      </ul>
      <ul class="nav navbar-nav navbar-right">
   
        <li><a href="a_logout.php">Logout &nbsp <i class="fa fa-sign-out" aria-hidden="true"></i></a></li>
      </ul>
    </div>
  </div>
 </nav>
   <br><br>
<div class="video" style="margin-top: 5%"> 
	<div class="center-container">
		 <div class="bg-agile">
			<br><br>
			<div class="login-form"><p><h2>Add User</h2></p><br>	
            <form action="#" method="post" style="color: gray">
    User name<input type="text" name="user_name" placeholder="User Name" required="" id="uname" onfocusout="f1()"/>
    User Id<input type="text" name="user_id" placeholder="User Id" required="" id="uid" onfocusout="f1()"/>
    Password<input type="text" name="password" placeholder="Password" id="password" required="" onfocusout="f1()"/>
    Address<input type="text" name="address" placeholder="Address" id="" required="" onfocusout="f1()"/>
    Adhar<input type="text" name="adhar" placeholder="Adhar No" id="" onfocusout="f1()" required maxlength="12"/>
    Mobile<input type="text" name="mobile" placeholder="Mobile" id="pas" onfocusout="f1()" required maxlength="10"/>
    Gender<select name="gender" id="gender" required="">
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Others">Others</option>
        </select>
        <input type="submit" value="Submit" name="s">
    <br>
</form>

			</div>	
		</div>
	</div>	
</div>	
 <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.4.js"></script>
 <script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
</body>
</html>
