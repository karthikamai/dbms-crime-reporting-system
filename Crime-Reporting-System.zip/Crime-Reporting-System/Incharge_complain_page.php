<!DOCTYPE html>
<html>
<head>
<?php
session_start();
if (!isset($_SESSION['x'])) {
    header("location:inchargelogin.php");
    exit(); // Stop further execution
}

$conn = mysqli_connect("localhost", "root", "", "crime_portal");
if (!$conn) {
    die("Could not connect" . mysqli_error());
}
mysqli_select_db($conn, 'crime_portal');

$i_id = $_SESSION['email'];
$result1 = mysqli_query($conn, "SELECT location FROM police_station where i_id='$i_id'");
if ($result1) {
    if (mysqli_num_rows($result1) > 0) {
        $q2 = mysqli_fetch_assoc($result1);
        $location = $q2['location'];
    } else {
        echo "Error: No location found for the incharge";
        exit();
    }
} else {
    echo "Error: Unable to execute query to fetch location from police_station";
    exit();
}


$c_police_id = ""; // Initialize $c_police_id with an empty string

if (isset($_POST['s2'])) {
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $cid = $_POST['cid'];

        $_SESSION['cid'] = $cid;
        $qu = mysqli_query($conn, "select inc_status, location from complaint where c_id='$cid'");

        $q = mysqli_fetch_assoc($qu);
        $inc_st = $q['inc_status'];
        $loc = $q['location'];

        if (strcmp("$loc", "$location") != 0) {
            $msg = "Case Not of your Location";
            echo "<script type='text/javascript'>alert('$msg');</script>";
        } elseif (strcmp("$inc_st", "Unassigned") == 0) {
            header("location:Incharge_complain_details.php");
            exit(); // Stop further execution
        } else {
            header("location:incharge_complain_details1.php");
            exit(); // Stop further execution
        }
    }
}
if (isset($_POST['status'])) {
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
      if (isset($_POST['c_id']) && isset($_POST['pol_status'])) {
          $c_id = $_POST['c_id'];
          $pol_status = $_POST['pol_status'];

          // Fetch the location of the police officer
          $police_location_query = "SELECT location FROM police WHERE p_id='$pol_status'";
          $police_location_result = mysqli_query($conn, $police_location_query);

          if ($police_location_result) {
              $police_row = mysqli_fetch_assoc($police_location_result);
              $police_location = $police_row['location'];

              // Fetch the location of the complaint
              $complaint_location_query = "SELECT location FROM complaint WHERE c_id='$c_id'";
              $complaint_location_result = mysqli_query($conn, $complaint_location_query);

              if ($complaint_location_result) {
                  $complaint_row = mysqli_fetch_assoc($complaint_location_result);
                  $complaint_location = $complaint_row['location'];

                  if ($complaint_location != $police_location) {
                      $msg = "Police Location and Complaint Location do not match!";
                      echo "<script type='text/javascript'>alert('$msg');</script>";
                  } else {
                      // Update complaint table
                      $query_update = "UPDATE complaint SET p_id='$pol_status', inc_status='Assigned', pol_status='In Process' WHERE c_id='$c_id'";
                      $result_update = mysqli_query($conn, $query_update);

                      if ($result_update) {
                          $msg = "Police ID and Status Updated Successfully!";
                          echo "<script type='text/javascript'>alert('$msg');</script>";
                      } else {
                          $msg = "Failed to Update Police ID and Status!";
                          echo "<script type='text/javascript'>alert('$msg');</script>";
                      }
                  }
              } else {
                  $msg = "Failed to fetch complaint location!";
                  echo "<script type='text/javascript'>alert('$msg');</script>";
              }
          } else {
              $msg = "Invalid Police ID!";
              echo "<script type='text/javascript'>alert('$msg');</script>";
          }
      } else {
          $msg = "Case ID and Police ID are required!";
          echo "<script type='text/javascript'>alert('$msg');</script>";
      }
  }
}


$query = "SELECT c_id, type_crime, d_o_c, location, inc_status, p_id FROM complaint WHERE location='$location' ORDER BY c_id DESC";
$result = mysqli_query($conn, $query);
?>
	<title>Incharge Homepage</title>
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
	<link href="http://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">
	
    <script>
     function f1()
        {
          var sta2=document.getElementById("ciid").value;
          var x2=sta2.indexOf(' ');
     if(sta2!="" && x2>=0)
     {
        document.getElementById("ciid").value="";
        alert("Blank Field not Allowed");
      }       
}
</script>
    
</head>
<body style="background-color: #dfdfdf">
	<nav  class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="home.php"><b>Crime Portal</b></a>
    </div>
    <div id="navbar" class="collapse navbar-collapse">
      <ul class="nav navbar-nav">
        <li ><a href="official_login.php">Official Login</a></li>
        <li ><a href="inchargelogin.php">Incharge Login</a></li>
        <li class="active"><a href="Incharge_complain_page.php">Incharge Home</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li class="active" ><a href="Incharge_complain_page.php">View Complaints</a></li>
        <li ><a href="incharge_view_police.php">Police Officers</a></li>
        <li><a href="inc_logout.php">Logout &nbsp <i class="fa fa-sign-out" aria-hidden="true"></i></a></li>
      </ul>
    </div>
  </div>
 </nav>
    
    <form style="margin-top: 7%; margin-left: 40%;" method="post">
      <input type="text" name="cid" style="width: 250px; height: 30px; background-color:white;" placeholder="&nbsp Complaint Id" id="ciid" onfocusout="f1()" required>
        <div>
      <input class="btn btn-primary" type="submit" value="Search" name="s2" style="margin-top: 10px; margin-left: 11%;">
        </div>
    </form>
    
    
    
 <div style="padding:50px;">
   <table class="table table-bordered">
    <thead class="thead-dark" style="background-color: black; color: white;">
      <tr>
        <th scope="col">Complaint Id</th>
        <th scope="col">Type of Crime</th>
        <th scope="col">Date of Crime</th>
        <th scope="col">Location</th>
        <th scope="col">Complaint Status</th>
          <th scope="col">Police ID</th>
      </tr>
    </thead>

            <?php
              while($rows=mysqli_fetch_assoc($result)){

             ?> 

            <tbody style="background-color: white; color: black;">
      <tr>
        <td><?php echo $rows['c_id'];?></td>
        <td><?php echo $rows['type_crime'];?></td>     
        <td><?php echo $rows['d_o_c'];?></td>
          <td><?php echo $rows['location'];?></td>
          <td><?php echo $rows['inc_status']; ?></td>
          <td><?php echo $rows['p_id']; ?></td>
      </tr>
    </tbody>
    
    <?php
    } 
    ?>
  
</table>
 </div>


 <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.4.js"></script>
 <script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
</body>
</html>
